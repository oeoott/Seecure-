document.addEventListener('DOMContentLoaded', () => {
  const root = document.getElementById('root');
  root.innerText = "여기에 AI 응답을 띄워요!";
  // 필요하다면 백엔드 호출 코드(fetch)도 넣어줌
});
