// 페이지가 로드될 때 팝업 버튼을 추가하거나,
// 페이지 조건(보호 옵션 등)을 체크해서
// 메시지를 popup.js 로 보내는 용도
console.log("Content script 실행됨");
